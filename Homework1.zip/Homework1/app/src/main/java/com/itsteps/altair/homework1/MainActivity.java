package com.itsteps.altair.homework1;


import java.util.Locale;

import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.os.Bundle;


public class MainActivity extends AppCompatActivity {

    String mLang;
    private Locale mNewLocale;
    String mLang2;
    private Locale mNewLocale2;
    TextView txtV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button ruBtn = (Button) findViewById(R.id.button1);
        Button enBtn = (Button) findViewById(R.id.button2);

        OnClickListener clickBtn = new OnClickListener() {
            @Override
            public void onClick(View v) {
                switch(v.getId()) {
                    case R.id.button1:
                        setLocale2("fr");
                        break;
                    case R.id.button2:
                        setLocale("ru");
                        break;
                    //default:

                }
            }
        };

        ruBtn.setOnClickListener(clickBtn);
        enBtn.setOnClickListener(clickBtn);

    }

    void updateTextView() {
        txtV = (TextView) findViewById(R.id.textView1);
        txtV.setText(getResources().getString(R.string.text));
        txtV = (TextView) findViewById(R.id.textView2);
        txtV.setText(getResources().getString(R.string.text2));
    }

    void updateTextView2() {
        txtV = (TextView) findViewById(R.id.textView1);
        txtV.setText(getResources().getString(R.string.text));
        txtV = (TextView) findViewById(R.id.textView2);
        txtV.setText(getResources().getString(R.string.text2));
    }

    void setLocale(String mLang) {
        mNewLocale = new Locale(mLang);
        Locale.setDefault(mNewLocale);
        android.content.res.Configuration config = new android.content.res.Configuration();
        config.locale = mNewLocale;
        getResources().updateConfiguration(config, getResources().getDisplayMetrics());
        updateTextView();
    }

    void setLocale2(String mLang2) {
        mNewLocale2 = new Locale(mLang2);
        Locale.setDefault(mNewLocale2);
        android.content.res.Configuration config = new android.content.res.Configuration();
        config.locale = mNewLocale2;
        getResources().updateConfiguration(config, getResources().getDisplayMetrics());
        updateTextView2();
    }
}